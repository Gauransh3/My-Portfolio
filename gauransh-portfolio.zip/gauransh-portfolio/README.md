# ⚡ Gauransh | Personal Developer Portfolio

> **A modern, premium, futuristic, and fully responsive personal portfolio website for Gauransh**, BCA 2nd-Year student at Swami Rama Himalayan University (SRHU), Uttarakhand, India.

---

## 🌟 Highlights & Features

- **Futuristic Obsidian & Cyberpunk Design:** Dark theme with deep navy/black hues (`#030712`), electric cyan (`#00f2fe`), electric blue (`#4facfe`), and royal purple (`#a855f7`) accents.
- **Interactive Developer Hero:** Includes an interactive C code terminal simulating Gauransh's academic profile with a working "Run Code" execution trigger.
- **Authentic About Section:** Highlights his BCA journey at SRHU, algorithmic foundation in C & Data Structures, and curiosity for AI/ML & Data Science without exaggeration.
- **Categorized Skills Matrix:**
  - **Programming:** C Language, Data Structures (in C)
  - **Web Development:** HTML5, CSS3, JavaScript (ES6+)
  - **Computer Science:** Data Structures, Problem-Solving, Database Fundamentals
  - **Areas of Interest:** AI/ML, Data Science, Mobile App Development
- **Featured Projects Showcase:**
  - **Fitness & Sports Competition App:** Highlighted hero project card with running challenge specs, simulated leaderboard preview, and interactive architecture deep-dive modal.
  - **BCA Academic & Task Planner:** Practical student utility tool for daily coding tracking and syllabus checklists.
  - **C Algorithm Visualizer Concept:** Visual tool demystifying memory pointers and sorting routines.
- **SRHU Education Card:** Highlights Swami Rama Himalayan University, BCA 2nd-year status, and coursework.
- **Currently Learning Track:** Active roadmap covering AI/ML, Data Science, Software Development, and Advanced DSA.
- **Verified Milestones & Achievements:** Authentic records with no fabricated awards or fake internships, plus future-ready placeholders.
- **Functional Contact Section:** Real-time form validation, celebration confetti effect, email draft trigger, and 1-click clipboard copy with instant checkmark feedback.

---

## 🚀 Quick Start Instructions

### Prerequisites
Make sure you have **Node.js** (v18 or newer) installed.

### 1. Open Terminal in the Project Directory
```bash
cd "c:\Users\DELL\OneDrive\Desktop\gauransh-portfolio"
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Launch Development Server
```bash
npm run dev
```

Visit the local URL shown in your terminal (usually `http://localhost:3000` or `http://localhost:5173`) in your browser.

### 4. Build for Production
To create an optimized production build:
```bash
npm run build
```
The output files will be in the `dist/` directory, ready to deploy.

---

## 🛠️ How to Customize Your Portfolio in 2 Minutes

All personal information, links, projects, and skills are centralized in a single configuration file:
👉 **`src/data/portfolioData.js`**

### Update Your Contact & Social Links
Open `src/data/portfolioData.js` and edit:
```javascript
export const personalInfo = {
  name: "Gauransh",
  email: "your-real-email@gmail.com",       // <-- Change this
  github: "https://github.com/your-username", // <-- Change this
  linkedin: "https://linkedin.com/in/your-username", // <-- Change this
  // ...
};
```

### Add or Edit Projects
In the same file, locate `featuredProjects` to update GitHub URLs, live links, or add new projects:
```javascript
export const featuredProjects = [
  {
    id: "fitness-sports-app",
    title: "Fitness & Sports Competition App",
    githubUrl: "https://github.com/your-username/fitness-app", // Add your repo
    // ...
  }
];
```

### Update Skills or Coursework
Find `skillsData` or `educationData` in `src/data/portfolioData.js` to modify your subjects as you progress through your 2nd and 3rd year at SRHU.

---

## 🌐 Free One-Click Deployment Options

### Deploy to Vercel (Recommended)
1. Push your code to a GitHub repository.
2. Sign in to [vercel.com](https://vercel.com) using your GitHub account.
3. Click **"Add New Project"** and select your `gauransh-portfolio` repository.
4. Framework preset will automatically detect **Vite**.
5. Click **"Deploy"**! Your site will be live with a free SSL certificate.

### Deploy to Netlify
1. Sign in to [netlify.com](https://netlify.com).
2. Drag and drop the `dist/` folder after running `npm run build`, or connect directly to your GitHub repository.

---

## 📂 Project Structure

```
gauransh-portfolio/
├── index.html                   # SEO tags, meta descriptions, and Google Fonts
├── package.json                 # Project dependencies & scripts
├── postcss.config.js            # PostCSS configuration
├── tailwind.config.js           # Custom theme colors, glows, and animations
├── vite.config.js               # Vite configuration (port 3000)
├── README.md                    # Setup and customization guide
└── src/
    ├── App.jsx                  # Main application structure
    ├── main.jsx                 # Entry point
    ├── index.css                # Glassmorphic utilities, glow effects, scrollbar
    ├── data/
    │   └── portfolioData.js     # Single source of truth for all content
    └── components/
        ├── Navbar.jsx           # Futuristic glass navbar with mobile menu
        ├── Hero.jsx             # Hero with interactive C code playground
        ├── About.jsx            # Authentic SRHU BCA story and focus pillars
        ├── Skills.jsx           # Filterable categorized skill cards
        ├── Projects.jsx         # Spotlight on Fitness App & project cards
        ├── ProjectModal.jsx     # Deep-dive architecture & specs modal
        ├── Education.jsx        # SRHU degree timeline & coursework tags
        ├── Learning.jsx         # Currently learning track cards
        ├── Achievements.jsx     # Transparent academic milestones
        ├── Contact.jsx          # Interactive form, email copy & confetti
        └── Footer.jsx           # Copyright 2026, motto & back-to-top
```

---

**Gauransh © 2026** • *"Designed with curiosity. Built with code."*

