import React from 'react';
import { 
  Code2, 
  Cpu, 
  Rocket, 
  Sparkles, 
  MapPin, 
  GraduationCap, 
  Compass, 
  Target,
  BookOpen
} from 'lucide-react';
import { personalInfo, aboutData } from '../data/portfolioData';

export default function About() {
  const iconMap = {
    Code2: Code2,
    Cpu: Cpu,
    Rocket: Rocket,
    Sparkles: Sparkles,
  };

  return (
    <section id="about" className="py-20 relative overflow-hidden border-t border-white/5">
      {/* Background accents */}
      <div className="absolute top-1/2 -left-48 w-80 h-80 bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-10 -right-48 w-80 h-80 bg-purple-600/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-mono font-medium tracking-wide">
            <Compass className="w-3.5 h-3.5" />
            <span>ABOUT ME</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Curious by Nature. <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Driven by Code.</span>
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            An authentic look at my journey as an undergraduate computer applications student at SRHU, exploring the intersection of programming and artificial intelligence.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Authentic Story & Bio */}
          <div className="lg:col-span-7 space-y-6">
            <div className="glass-card p-6 sm:p-8 rounded-2xl border border-white/10 space-y-5 text-slate-300 leading-relaxed text-base">
              
              <div className="flex items-center gap-3 pb-3 border-b border-white/10">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Undergraduate Journey</h3>
                  <p className="text-xs font-mono text-cyan-400">SRHU • BCA Second Year</p>
                </div>
              </div>

              {aboutData.intro.map((paragraph, idx) => (
                <p key={idx} className="text-slate-300">
                  {paragraph}
                </p>
              ))}

              {/* Career Goal Box */}
              <div className="mt-6 p-4 sm:p-5 rounded-xl bg-gradient-to-r from-cyan-950/40 via-purple-950/30 to-slate-900 border border-cyan-500/20">
                <div className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-cyan-300 uppercase tracking-wider font-mono">
                      Career Objective
                    </h4>
                    <p className="text-sm text-slate-300 mt-1 leading-normal italic">
                      "{personalInfo.careerGoal}"
                    </p>
                  </div>
                </div>
              </div>

            </div>

            {/* Quick Stats / Highlights */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {aboutData.quickStats.map((item, idx) => (
                <div key={idx} className="glass-card p-4 rounded-xl border border-white/5 text-center">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                    {item.label}
                  </span>
                  <span className="text-sm font-bold text-slate-100 mt-1 block">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: 4 Focus Pillars */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 mb-2 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-purple-400" />
              Core Pillars of My Exploration
            </h3>

            {aboutData.pillars.map((pillar, idx) => {
              const IconComponent = iconMap[pillar.icon] || Sparkles;
              return (
                <div
                  key={idx}
                  className="glass-card glass-card-hover p-5 rounded-xl border border-white/10 group"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0 group-hover:scale-105 group-hover:bg-purple-500/20 transition-all">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                        {pillar.title}
                      </h4>
                      <p className="text-sm text-slate-400 mt-1 leading-relaxed">
                        {pillar.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Location & University Card */}
            <div className="glass-card p-4 rounded-xl border border-white/10 flex items-center justify-between text-xs font-mono text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400" />
                <span>Dehradun, Uttarakhand, India</span>
              </div>
              <span className="text-purple-400">SRHU Campus</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}

