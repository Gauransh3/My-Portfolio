import React from 'react';
import { Award, Calendar, CheckCircle2, ShieldCheck, Sparkles, PlusCircle } from 'lucide-react';
import { achievementsData } from '../data/portfolioData';

export default function Achievements() {
  const getTypeBadgeClass = (type) => {
    switch (type) {
      case 'Academic':
        return 'bg-blue-500/10 text-blue-300 border-blue-500/20';
      case 'Workshop':
        return 'bg-purple-500/10 text-purple-300 border-purple-500/20';
      case 'Technical Milestone':
        return 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20';
      default:
        return 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20';
    }
  };

  return (
    <section id="achievements" className="py-20 relative overflow-hidden border-t border-white/5">
      {/* Background glow */}
      <div className="absolute top-1/2 -right-40 w-80 h-80 bg-purple-600/10 rounded-full blur-[130px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-medium tracking-wide">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>AUTHENTIC MILESTONES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Academic & <span className="bg-gradient-to-r from-emerald-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">Technical Milestones</span>
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            {achievementsData.note}
          </p>
        </div>

        {/* Milestone Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {achievementsData.items.map((item, idx) => (
            <div
              key={idx}
              className="glass-card glass-card-hover rounded-2xl p-6 border border-white/10 flex flex-col justify-between group"
            >
              <div className="space-y-3">
                
                {/* Header row: Type and Year */}
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono border ${getTypeBadgeClass(item.type)}`}>
                    {item.type}
                  </span>
                  <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-cyan-400" />
                    {item.year}
                  </span>
                </div>

                {/* Milestone Title */}
                <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {item.title}
                </h3>

                {/* Organization */}
                <p className="text-xs font-mono text-cyan-400 font-medium">
                  {item.organization}
                </p>

                {/* Description */}
                <p className="text-sm text-slate-300 leading-relaxed pt-1">
                  {item.description}
                </p>
              </div>

              {/* Verified Tag */}
              <div className="mt-5 pt-3 border-t border-white/5 flex items-center gap-1.5 text-[11px] font-mono text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Activity</span>
              </div>
            </div>
          ))}

          {/* Extensibility Placeholder Card */}
          <div className="rounded-2xl p-6 border border-dashed border-white/15 bg-white/[0.01] flex flex-col items-center justify-center text-center space-y-3 hover:border-cyan-500/40 hover:bg-white/[0.02] transition-all">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <PlusCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-200">
                Ready for New Certifications & Hackathons
              </h4>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                Easily update `portfolioData.js` as upcoming 2026 hackathons and technical certifications are completed.
              </p>
            </div>
            <span className="text-[11px] font-mono text-purple-400 bg-purple-500/10 px-3 py-1 rounded-full border border-purple-500/20">
              Future Ready
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}

