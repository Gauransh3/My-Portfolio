import React from 'react';
import { GraduationCap, MapPin, Calendar, BookOpen, CheckCircle, Award } from 'lucide-react';
import { educationData } from '../data/portfolioData';

export default function Education() {
  return (
    <section id="education" className="py-20 relative overflow-hidden border-t border-white/5">
      {/* Background Glow */}
      <div className="absolute top-1/2 -right-40 w-96 h-96 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-medium tracking-wide">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>ACADEMIC FOUNDATION</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Education & <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">University Life</span>
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            My formal computer science and applications background at Swami Rama Himalayan University, building core analytical and programming competence.
          </p>
        </div>

        {/* Education Hero Card */}
        <div className="max-w-4xl mx-auto">
          <div className="relative glass-card rounded-2xl p-6 sm:p-10 border border-white/10 shadow-2xl backdrop-blur-xl group hover:border-cyan-500/30 transition-all duration-300">
            
            {/* Ambient accent top bar */}
            <div className="absolute top-0 left-8 right-8 h-[2px] bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500"></div>

            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 pb-6 border-b border-white/10">
              
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>{educationData.currentStatus}</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {educationData.degree}
                </h3>

                <h4 className="text-lg font-semibold text-cyan-400 flex items-center gap-2">
                  <span>{educationData.university}</span>
                </h4>

                <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-1">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-purple-400" />
                    {educationData.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                    {educationData.duration}
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              <div className="shrink-0 flex md:flex-col items-center md:items-end justify-between md:justify-start gap-2 bg-slate-900/60 p-4 rounded-xl border border-white/5">
                <span className="text-[11px] font-mono text-slate-400 uppercase">Degree Type</span>
                <span className="text-sm font-bold text-white font-mono">Undergraduate</span>
                <span className="text-[11px] font-mono text-cyan-400">Semester Coursework</span>
              </div>

            </div>

            {/* Description & Overview */}
            <div className="py-6 space-y-4 text-slate-300 text-sm leading-relaxed">
              <p>{educationData.description}</p>
              <p className="text-xs sm:text-sm text-slate-400 italic">
                "{educationData.academicFocus}"
              </p>
            </div>

            {/* Coursework & Focus Areas */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-mono uppercase tracking-wider text-purple-400 font-semibold flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4" />
                  Key Coursework & Lab Studies
                </h4>
                <span className="text-[11px] font-mono text-slate-500">Continuously updated</span>
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                {educationData.coursework.map((course, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-white/[0.03] text-slate-200 border border-white/10 hover:border-cyan-500/40 hover:bg-cyan-500/5 transition-colors"
                  >
                    <CheckCircle className="w-3 h-3 text-cyan-400" />
                    {course}
                  </span>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}

