import React from 'react';
import { ArrowUp, Terminal, Github, Linkedin, Mail, Heart } from 'lucide-react';
import { personalInfo } from '../data/portfolioData';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-white/10 bg-space-950/80 backdrop-blur-xl relative overflow-hidden">
      
      {/* Subtle top glow line */}
      <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center justify-between pb-8 border-b border-white/5">
          
          {/* Left: Brand & Description */}
          <div className="md:col-span-6 space-y-2 text-left">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Terminal className="w-4 h-4" />
              </div>
              <span className="font-mono text-lg font-bold text-white tracking-tight">
                {personalInfo.name}
                <span className="text-cyan-400">.</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 max-w-sm">
              Second-Year BCA Undergrad at Swami Rama Himalayan University (SRHU), Uttarakhand. Exploring software development, AI/ML, and Data Science.
            </p>
          </div>

          {/* Center / Navigation Links */}
          <div className="md:col-span-3">
            <ul className="flex flex-wrap gap-x-5 gap-y-2 text-xs font-mono text-slate-400">
              <li><a href="#about" className="hover:text-cyan-400 transition-colors">About</a></li>
              <li><a href="#skills" className="hover:text-cyan-400 transition-colors">Skills</a></li>
              <li><a href="#projects" className="hover:text-cyan-400 transition-colors">Projects</a></li>
              <li><a href="#education" className="hover:text-cyan-400 transition-colors">Education</a></li>
              <li><a href="#learning" className="hover:text-cyan-400 transition-colors">Learning</a></li>
              <li><a href="#contact" className="hover:text-cyan-400 transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Right: Social Icons & Back to Top */}
          <div className="md:col-span-3 flex items-center md:justify-end gap-3">
            <a
              href={personalInfo.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub Profile"
              className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href={personalInfo.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn Profile"
              className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 flex items-center justify-center text-slate-300 hover:text-cyan-400 transition-all"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href={`mailto:${personalInfo.email}`}
              aria-label="Direct Email"
              className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 flex items-center justify-center text-slate-300 hover:text-purple-400 transition-all"
            >
              <Mail className="w-4 h-4" />
            </a>

            <button
              onClick={scrollToTop}
              aria-label="Scroll back to top"
              className="w-9 h-9 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 transition-all"
              title="Back to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Bottom Copyright & Tagline */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-400">
          <div>
            <span className="font-semibold text-slate-200">{personalInfo.name} © 2026</span>
            <span className="mx-2 text-slate-600">•</span>
            <span>Swami Rama Himalayan University (SRHU)</span>
          </div>

          <div className="text-slate-400">
            "Designed with curiosity. Built with code."
          </div>
        </div>

      </div>
    </footer>
  );
}

