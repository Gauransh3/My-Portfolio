import React, { useState } from 'react';
import { ArrowRight, Terminal, Sparkles, Send, Play, CheckCircle2, Code2, MapPin, GraduationCap } from 'lucide-react';
import { personalInfo } from '../data/portfolioData';

export default function Hero() {
  const [isRunning, setIsRunning] = useState(false);
  const [showOutput, setShowOutput] = useState(false);

  const handleRunCode = () => {
    setIsRunning(true);
    setShowOutput(false);
    setTimeout(() => {
      setIsRunning(false);
      setShowOutput(true);
    }, 600);
  };

  return (
    <section id="hero" className="relative min-h-[92vh] flex items-center justify-center pt-28 pb-16 overflow-hidden">
      {/* Background Futuristic Ambient Gradients & Grid */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Glow Spheres */}
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-cyan-500/15 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div className="absolute top-1/3 -right-40 w-[28rem] h-[28rem] bg-purple-600/15 rounded-full blur-[140px] animate-pulse-slow"></div>
        <div className="absolute -bottom-20 left-1/3 w-80 h-80 bg-blue-600/10 rounded-full blur-[100px]"></div>
        
        {/* Subtle Futuristic Grid Background */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.12) 1px, transparent 0)`,
            backgroundSize: '36px 36px'
          }}
        ></div>
        {/* Bottom Fade */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-space-950 to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Hero Text & Actions */}
          <div className="lg:col-span-7 text-left space-y-6">
            
            {/* Status / University Pill */}
            <div className="inline-flex flex-wrap items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs text-slate-300 shadow-lg shadow-cyan-500/5">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="font-medium text-cyan-300">BCA 2nd Year Student</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-300 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-purple-400 inline" />
                SRHU, Uttarakhand
              </span>
            </div>

            {/* Main Greeting & Name */}
            <div className="space-y-3">
              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.1]">
                Hi, I'm <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-500 bg-clip-text text-transparent text-glow">Gauransh</span>.
              </h1>
              <p className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-200">
                {personalInfo.headline}
              </p>
            </div>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg text-slate-400 leading-relaxed max-w-2xl">
              {personalInfo.subtext}
            </p>

            {/* Quick Meta Badges */}
            <div className="flex flex-wrap gap-2 text-xs font-mono text-slate-300 pt-1">
              <span className="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/10 flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-cyan-400" /> C & Data Structures
              </span>
              <span className="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/10 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" /> AI/ML Explorer
              </span>
              <span className="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/10 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-blue-400" /> Swami Rama Himalayan University
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <a
                href="#projects"
                className="group relative inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 rounded-xl shadow-xl shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
              >
                <span>View My Projects</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>

              <a
                href="#contact"
                className="group inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-slate-200 bg-slate-900/80 hover:bg-slate-800/80 border border-slate-700/80 hover:border-cyan-500/40 rounded-xl shadow-lg transition-all duration-200 hover:text-white"
              >
                <Send className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
                <span>Get In Touch</span>
              </a>
            </div>

          </div>

          {/* Right Column: Interactive Code Terminal */}
          <div className="lg:col-span-5 relative">
            
            {/* Ambient Backlight */}
            <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-500/30 to-purple-600/30 rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>

            {/* Terminal Window */}
            <div className="relative rounded-2xl bg-space-900/95 border border-white/10 shadow-2xl overflow-hidden backdrop-blur-xl">
              
              {/* Window Header */}
              <div className="flex items-center justify-between px-4 py-3 bg-slate-950/80 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                  <span className="ml-2 text-xs font-mono text-slate-400 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                    gauransh_srhu.c
                  </span>
                </div>
                
                {/* Run Button */}
                <button
                  onClick={handleRunCode}
                  disabled={isRunning}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono font-medium rounded-md bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-all active:scale-95"
                  title="Execute simulated C program"
                >
                  <Play className={`w-3 h-3 ${isRunning ? 'animate-spin' : ''}`} />
                  {isRunning ? 'Compiling...' : 'Run Code'}
                </button>
              </div>

              {/* Code Snippet */}
              <div className="p-4 sm:p-5 font-mono text-xs sm:text-[13px] leading-relaxed text-slate-300 overflow-x-auto space-y-1">
                <div className="text-slate-500">// BCA 2nd-Year Undergrad @ SRHU Uttarakhand</div>
                <div><span className="text-purple-400">#include</span> <span className="text-emerald-300">&lt;stdio.h&gt;</span></div>
                <div className="text-slate-500">// Personal developer profile definition</div>
                <div>
                  <span className="text-blue-400">typedef struct</span> &#123;
                </div>
                <div className="pl-4 text-slate-300">
                  <span className="text-cyan-400">char*</span> name;<br />
                  <span className="text-cyan-400">char*</span> university;<br />
                  <span className="text-cyan-400">int</span> currentYear;<br />
                  <span className="text-cyan-400">char*</span> interests[<span className="text-amber-400">3</span>];
                </div>
                <div>&#125; <span className="text-amber-300">Developer</span>;</div>
                <br />
                <div>
                  <span className="text-blue-400">int</span> <span className="text-emerald-400">main</span>() &#123;
                </div>
                <div className="pl-4 space-y-0.5">
                  <div>
                    <span className="text-amber-300">Developer</span> g = &#123;
                  </div>
                  <div className="pl-4">
                    .name = <span className="text-emerald-300">"{personalInfo.name}"</span>,<br />
                    .university = <span className="text-emerald-300">"SRHU, Uttarakhand"</span>,<br />
                    .currentYear = <span className="text-amber-400">2</span>,<br />
                    .interests = &#123;<span className="text-emerald-300">"Software Dev"</span>, <span className="text-emerald-300">"AI/ML"</span>, <span className="text-emerald-300">"Data Science"</span>&#125;
                  </div>
                  <div>&#125;;</div>
                  <div className="text-cyan-400 pt-1">
                    printf(<span className="text-emerald-300">"Building ideas into reality with code.\n"</span>);
                  </div>
                  <div>
                    <span className="text-purple-400">return</span> <span className="text-amber-400">0</span>;
                  </div>
                </div>
                <div>&#125;</div>
              </div>

              {/* Terminal Output Tray */}
              <div className="border-t border-white/10 bg-slate-950 p-3 sm:p-4 font-mono text-xs">
                <div className="flex items-center justify-between text-slate-500 mb-1.5 text-[11px]">
                  <span>TERMINAL CONSOLE</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    GCC Ready
                  </span>
                </div>
                
                {showOutput ? (
                  <div className="space-y-1 text-slate-300 animate-fadeIn">
                    <div className="text-cyan-400">$ gcc gauransh_srhu.c -o gauransh && ./gauransh</div>
                    <div className="text-emerald-300 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />
                      Building ideas into reality with code.
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      [INFO] Status: BCA 2nd-Year • Passionate about AI/ML, Data Science & Software Solutions.
                    </div>
                  </div>
                ) : (
                  <div className="text-slate-500 flex items-center justify-between">
                    <span>Click "Run Code" above to execute...</span>
                    <span className="animate-pulse">_</span>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
}

