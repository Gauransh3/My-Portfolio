import React from 'react';
import { 
  Brain, 
  BarChart3, 
  Code, 
  Binary, 
  Sparkles, 
  CheckCircle2, 
  Flame, 
  Compass,
  ArrowRight
} from 'lucide-react';
import { currentlyLearningData } from '../data/portfolioData';

export default function Learning() {
  const iconMap = {
    Brain: Brain,
    BarChart3: BarChart3,
    Code: Code,
    Binary: Binary,
  };

  return (
    <section id="learning" className="py-20 relative overflow-hidden border-t border-white/5">
      {/* Background radial glow */}
      <div className="absolute top-1/2 -left-36 w-80 h-80 bg-cyan-600/10 rounded-full blur-[130px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-mono font-medium tracking-wide">
            <Sparkles className="w-3.5 h-3.5" />
            <span>GROWTH & HORIZONS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Currently <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">Learning & Exploring</span>
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            Beyond standard coursework, here are the technical frontiers I am dedicating active hours to explore through experimentation and self-study.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {currentlyLearningData.map((item, idx) => {
            const Icon = iconMap[item.icon] || Brain;
            return (
              <div
                key={idx}
                className="glass-card glass-card-hover rounded-2xl p-6 sm:p-7 border border-white/10 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  
                  {/* Top Bar: Icon + Status */}
                  <div className="flex items-center justify-between">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${item.accentColor} p-[1px] group-hover:scale-105 transition-transform`}>
                      <div className="w-full h-full bg-space-950 rounded-xl flex items-center justify-center text-cyan-400">
                        <Icon className="w-6 h-6" />
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono bg-white/[0.03] text-cyan-300 border border-cyan-500/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                      Active Track
                    </span>
                  </div>

                  {/* Topic Title */}
                  <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {item.topic}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Milestones / Checklist */}
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-purple-400 font-semibold block">
                      Active Exploration Areas:
                    </span>
                    <ul className="space-y-2">
                      {item.milestones.map((milestone, mIdx) => (
                        <li key={mIdx} className="flex items-start gap-2 text-xs text-slate-400">
                          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                          <span>{milestone}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* Footer badge */}
                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-500">
                  <span>Self-Directed & Campus Labs</span>
                  <span className="text-purple-400 flex items-center gap-1">
                    Continuous Study
                  </span>
                </div>

              </div>
            );
          })}
        </div>

        {/* Growth Philosophy Banner */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-space-900 via-slate-900 to-space-950 border border-cyan-500/20 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0 mx-auto sm:mx-0">
              <Flame className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Daily Learning Routine</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Balancing BCA lectures at SRHU with 1-2 hours of daily problem solving and software architecture experiments.
              </p>
            </div>
          </div>
          <a
            href="#projects"
            className="shrink-0 text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors"
          >
            <span>See Applied Work</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>

      </div>
    </section>
  );
}

