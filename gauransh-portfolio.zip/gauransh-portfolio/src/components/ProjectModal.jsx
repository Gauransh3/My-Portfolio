import React from 'react';
import { X, ExternalLink, Github, Layers, Target, CheckCircle2, AlertCircle, Sparkles, Trophy, Users, Activity } from 'lucide-react';

export default function ProjectModal({ project, onClose }) {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-md animate-fadeIn">
      
      {/* Backdrop click dismiss */}
      <div className="fixed inset-0" onClick={onClose}></div>

      {/* Modal Dialog Content */}
      <div className="relative w-full max-w-3xl bg-space-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col my-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 bg-slate-950/80 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold uppercase">
                  {project.status}
                </span>
                <span className="text-xs font-mono text-slate-400 hidden sm:inline">• Architectural Deep Dive</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-0.5">
                {project.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Close project modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-300 text-sm leading-relaxed">
          
          {/* Concept Transparency Notice */}
          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 flex items-start gap-3 text-cyan-200">
            <AlertCircle className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div className="text-xs sm:text-sm">
              <strong className="font-semibold text-white">Transparency Guarantee: </strong>
              This project is currently in the active architectural and concept design stage. All features described below represent the technical specification and planned roadmap designed by Gauransh.
            </div>
          </div>

          {/* Problem Statement */}
          <div className="space-y-2">
            <h4 className="text-xs font-mono uppercase tracking-wider text-purple-400 flex items-center gap-1.5 font-bold">
              <Target className="w-4 h-4" />
              The Problem Being Addressed
            </h4>
            <p className="text-slate-300 bg-white/[0.02] p-4 rounded-xl border border-white/5">
              {project.problemSolved}
            </p>
          </div>

          {/* Solution & Concept Architecture */}
          <div className="space-y-2">
            <h4 className="text-xs font-mono uppercase tracking-wider text-cyan-400 flex items-center gap-1.5 font-bold">
              <Sparkles className="w-4 h-4" />
              Proposed Solution & Mechanics
            </h4>
            <p className="text-slate-300 bg-white/[0.02] p-4 rounded-xl border border-white/5">
              {project.solution}
            </p>
          </div>

          {/* Key Feature Pillars */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-400 flex items-center gap-1.5 font-bold">
              <Activity className="w-4 h-4" />
              Target Platform Features
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {project.keyFeatures.map((feat, idx) => (
                <div key={idx} className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-950/60 border border-white/5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Planned Technology Stack */}
          <div className="space-y-2">
            <h4 className="text-xs font-mono uppercase tracking-wider text-blue-400 flex items-center gap-1.5 font-bold">
              <Layers className="w-4 h-4" />
              Planned Technology Stack
            </h4>
            <div className="flex flex-wrap gap-2 pt-1">
              {project.techStack.map((tech, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-lg text-xs font-mono bg-white/[0.04] text-slate-200 border border-white/10"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between p-5 bg-slate-950/90 border-t border-white/10">
          <span className="text-xs font-mono text-slate-400">
            SRHU Undergrad Project Concept
          </span>
          <div className="flex items-center gap-3">
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-mono rounded-lg bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 transition-colors"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GitHub Repository</span>
              </a>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

