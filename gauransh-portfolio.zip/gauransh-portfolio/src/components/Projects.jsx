import React, { useState } from 'react';
import { 
  FolderGit2, 
  ExternalLink, 
  Github, 
  Layers, 
  Trophy, 
  Activity, 
  Users, 
  Flame, 
  ArrowUpRight,
  Info,
  CheckCircle2
} from 'lucide-react';
import { featuredProjects } from '../data/portfolioData';
import ProjectModal from './ProjectModal';

export default function Projects() {
  const [activeModalProject, setActiveModalProject] = useState(null);

  const fitnessProject = featuredProjects.find(p => p.id === 'fitness-sports-app');
  const secondaryProjects = featuredProjects.filter(p => p.id !== 'fitness-sports-app');

  const getStatusBadgeClass = (statusType) => {
    switch (statusType) {
      case 'concept':
        return 'bg-purple-500/15 text-purple-300 border-purple-500/30';
      case 'in-progress':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      default:
        return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
    }
  };

  return (
    <section id="projects" className="py-20 relative overflow-hidden border-t border-white/5">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-0 w-80 h-80 bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-mono font-medium tracking-wide">
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>PROJECT SHOWCASE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Featured <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">Projects & Concepts</span>
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            Thoughtfully designed software concepts and work-in-progress applications addressing real user needs, clearly documented with genuine development status.
          </p>
        </div>

        {/* PRIMARY SPOTLIGHT PROJECT: Fitness & Sports Competition App */}
        {fitnessProject && (
          <div className="mb-14">
            <div className="relative rounded-2xl bg-gradient-to-b from-space-900 to-space-950 border border-cyan-500/30 shadow-2xl overflow-hidden backdrop-blur-xl group">
              
              {/* Glowing header banner line */}
              <div className="h-1.5 w-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600"></div>

              <div className="p-6 sm:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                
                {/* Left 7 Cols: Project Information */}
                <div className="lg:col-span-7 space-y-5">
                  
                  {/* Status & Badge Row */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold uppercase tracking-wider bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5">
                      <Trophy className="w-3.5 h-3.5 text-cyan-400" />
                      {fitnessProject.badge}
                    </span>
                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-mono border ${getStatusBadgeClass(fitnessProject.statusType)}`}>
                      Status: {fitnessProject.status}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight group-hover:text-cyan-300 transition-colors">
                    {fitnessProject.title}
                  </h3>

                  {/* Description */}
                  <p className="text-slate-300 text-base leading-relaxed">
                    {fitnessProject.shortDescription}
                  </p>

                  {/* Problem & Solution Compact Box */}
                  <div className="space-y-3 pt-2">
                    <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-1.5">
                      <span className="text-xs font-mono font-semibold text-purple-400 uppercase tracking-wider block">
                        Problem Solved:
                      </span>
                      <p className="text-xs sm:text-sm text-slate-300">
                        {fitnessProject.problemSolved}
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-1.5">
                      <span className="text-xs font-mono font-semibold text-cyan-400 uppercase tracking-wider block">
                        Core Platform Value:
                      </span>
                      <p className="text-xs sm:text-sm text-slate-300">
                        {fitnessProject.solution}
                      </p>
                    </div>
                  </div>

                  {/* Tech Stack Pills */}
                  <div className="space-y-2 pt-1">
                    <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">
                      Target Technologies
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {fitnessProject.techStack.map((tech, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-lg text-xs font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center gap-3 pt-4">
                    <button
                      onClick={() => setActiveModalProject(fitnessProject)}
                      className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-mono font-semibold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all"
                    >
                      <span>Explore Architecture & Specs</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>

                    {fitnessProject.githubUrl && (
                      <a
                        href={fitnessProject.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition-colors"
                      >
                        <Github className="w-4 h-4 text-slate-400" />
                        <span>GitHub Repo</span>
                      </a>
                    )}
                  </div>

                </div>

                {/* Right 5 Cols: Visual Simulation of the Fitness App UI Concept */}
                <div className="lg:col-span-5">
                  <div className="p-5 rounded-2xl bg-space-950/90 border border-white/10 space-y-4 shadow-xl">
                    
                    {/* Simulated App Card Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-white/10">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                          <Activity className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white">SRHU 5K Challenge</div>
                          <div className="text-[10px] font-mono text-cyan-400">Active Campus Sprint</div>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Live Tracking
                      </span>
                    </div>

                    {/* Simulated Metrics Grid */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                        <span className="text-[10px] font-mono text-slate-400 uppercase">Distance</span>
                        <span className="text-base font-bold text-cyan-400 block mt-0.5">5.20 km</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                        <span className="text-[10px] font-mono text-slate-400 uppercase">Avg Pace</span>
                        <span className="text-base font-bold text-purple-400 block mt-0.5">4'42" /km</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5 text-center">
                        <span className="text-[10px] font-mono text-slate-400 uppercase">Rank</span>
                        <span className="text-base font-bold text-amber-400 block mt-0.5">#2</span>
                      </div>
                    </div>

                    {/* Simulated Peer Leaderboard Preview */}
                    <div className="space-y-2 pt-1">
                      <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                        Live Challenge Leaderboard
                      </span>
                      
                      <div className="space-y-1.5 text-xs">
                        <div className="flex items-center justify-between p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center font-bold text-amber-400">1</span>
                            <span className="text-white font-medium">Campus Runner A.</span>
                          </div>
                          <span className="font-mono text-amber-300 font-semibold">21:15 min</span>
                        </div>

                        <div className="flex items-center justify-between p-2 rounded-lg bg-cyan-500/15 border border-cyan-500/30">
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center font-bold text-cyan-400">2</span>
                            <span className="text-cyan-300 font-medium">Gauransh (You)</span>
                          </div>
                          <span className="font-mono text-cyan-300 font-semibold">22:04 min</span>
                        </div>

                        <div className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02] border border-white/5">
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center text-slate-400">3</span>
                            <span className="text-slate-300">Peer Athlete D.</span>
                          </div>
                          <span className="font-mono text-slate-400">23:40 min</span>
                        </div>
                      </div>
                    </div>

                    {/* Card Feature tags */}
                    <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                      <span className="flex items-center gap-1 text-cyan-400">
                        <Users className="w-3.5 h-3.5" /> Social Invites
                      </span>
                      <span className="flex items-center gap-1 text-purple-400">
                        <Flame className="w-3.5 h-3.5" /> Streak Tracking
                      </span>
                    </div>

                  </div>
                </div>

              </div>
            </div>
          </div>
        )}

        {/* SECONDARY PROJECTS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {secondaryProjects.map((project) => (
            <div
              key={project.id}
              className="glass-card glass-card-hover rounded-2xl p-6 sm:p-7 border border-white/10 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                
                {/* Header Badge */}
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono border ${getStatusBadgeClass(project.statusType)}`}>
                    Status: {project.status}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {project.badge}
                  </span>
                </div>

                {/* Title */}
                <h4 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {project.title}
                </h4>

                {/* Short Description */}
                <p className="text-sm text-slate-300 leading-relaxed">
                  {project.shortDescription}
                </p>

                {/* Problem Addressed */}
                <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/5 text-xs text-slate-400 space-y-1">
                  <span className="font-mono text-purple-400 uppercase font-semibold block text-[10px]">
                    Focus Problem:
                  </span>
                  <p>{project.problemSolved}</p>
                </div>

                {/* Tech Badges */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {project.techStack.map((tech, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded text-[11px] font-mono bg-white/[0.03] text-slate-300 border border-white/10"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

              </div>

              {/* Card Footer / Action */}
              <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-[11px] font-mono text-slate-400">
                  Documented Spec
                </span>
                <div className="flex items-center gap-2">
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                      title="GitHub Repository"
                    >
                      <Github className="w-4 h-4" />
                    </a>
                  )}
                  <button
                    onClick={() => setActiveModalProject(project)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-mono bg-cyan-500/10 text-cyan-300 hover:bg-cyan-500/20 border border-cyan-500/30 transition-colors"
                  >
                    <span>Details</span>
                    <Info className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Project Architecture Modal */}
      {activeModalProject && (
        <ProjectModal
          project={activeModalProject}
          onClose={() => setActiveModalProject(null)}
        />
      )}
    </section>
  );
}

