import React, { useState } from 'react';
import { 
  Terminal, 
  Binary, 
  Layout, 
  Palette, 
  FileCode, 
  Layers, 
  Brain, 
  Database, 
  Bot, 
  LineChart, 
  Smartphone,
  Cpu,
  Sparkles,
  Check
} from 'lucide-react';
import { skillsData } from '../data/portfolioData';

export default function Skills() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const iconMap = {
    Terminal: Terminal,
    Binary: Binary,
    Layout: Layout,
    Palette: Palette,
    FileCode: FileCode,
    Layers: Layers,
    Brain: Brain,
    Database: Database,
    Bot: Bot,
    LineChart: LineChart,
    Smartphone: Smartphone,
    Cpu: Cpu
  };

  const categories = [
    { id: 'all', label: 'All Categories' },
    ...skillsData.categories.map(c => ({ id: c.id, label: c.name }))
  ];

  const displayedCategories = selectedCategory === 'all'
    ? skillsData.categories
    : skillsData.categories.filter(c => c.id === selectedCategory);

  return (
    <section id="skills" className="py-20 relative overflow-hidden border-t border-white/5">
      {/* Background glow */}
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-mono font-medium tracking-wide">
            <Cpu className="w-3.5 h-3.5" />
            <span>TECHNICAL CAPABILITIES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Skills & <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">Core Competencies</span>
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            A transparent and honest representation of my current technical toolset—centered around foundational programming, web basics, and exploratory areas in AI/ML and Data Science.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-mono transition-all duration-200 ${
                selectedCategory === cat.id
                  ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold shadow-lg shadow-purple-500/20'
                  : 'glass-card text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Categories and Skill Cards */}
        <div className="space-y-12">
          {displayedCategories.map((category) => (
            <div key={category.id} className="space-y-4">
              
              {/* Category Header */}
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-white/10 pb-3 gap-1">
                <div className="flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-cyan-400"></div>
                  <h3 className="text-xl font-bold text-white tracking-tight">
                    {category.name}
                  </h3>
                </div>
                <span className="text-xs font-mono text-slate-400">
                  {category.tagline}
                </span>
              </div>

              {/* Skills Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {category.skills.map((skill, sIdx) => {
                  const Icon = iconMap[skill.icon] || Terminal;
                  return (
                    <div
                      key={sIdx}
                      className="glass-card glass-card-hover rounded-xl p-5 border border-white/10 flex flex-col justify-between group"
                    >
                      <div>
                        {/* Top Row: Icon + Level Badge */}
                        <div className="flex items-center justify-between mb-3">
                          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-105 group-hover:border-cyan-400/40 transition-transform">
                            <Icon className="w-5 h-5" />
                          </div>
                          <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-white/[0.04] border border-white/10 text-slate-300">
                            {skill.levelNote}
                          </span>
                        </div>

                        {/* Skill Name */}
                        <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                          {skill.name}
                        </h4>

                        {/* Description */}
                        <p className="text-xs sm:text-sm text-slate-400 mt-1.5 leading-relaxed">
                          {skill.description}
                        </p>
                      </div>

                      {/* Card Footer Badge */}
                      <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-1.5 text-[11px] font-mono text-cyan-400">
                        <Check className="w-3 h-3 text-cyan-400" />
                        <span>Verified Coursework / Hands-on</span>
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          ))}
        </div>

        {/* Honest Transparency Note */}
        <div className="mt-12 text-center">
          <p className="inline-flex items-center gap-2 text-xs font-mono text-slate-500 bg-white/[0.02] border border-white/5 px-4 py-2 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Honest developer portfolio: Skills are accurately documented without fabricated percentage meters.</span>
          </p>
        </div>

      </div>
    </section>
  );
}

