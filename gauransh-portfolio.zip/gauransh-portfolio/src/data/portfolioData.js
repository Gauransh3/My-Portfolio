/**
 * Portfolio Data for Gauransh
 * BCA 2nd-Year Student at Swami Rama Himalayan University (SRHU), Uttarakhand, India.
 * 
 * Edit this single file to update your personal details, projects, skills, and links!
 */

export const personalInfo = {
  name: "Gauransh",
  firstName: "Gauransh",
  title: "Aspiring Software Developer | AI/ML & Data Science Enthusiast",
  headline: "I Build Ideas Into Reality With Code.",
  subtext: "I'm a second-year BCA student passionate about software development, AI/ML, and Data Science. I'm learning, experimenting, and building projects that solve real-world problems.",
  
  university: "Swami Rama Himalayan University (SRHU)",
  location: "Uttarakhand, India",
  degree: "Bachelor of Computer Applications (BCA)",
  currentYear: "2nd Year",
  graduationYear: "2027", // Editable expected graduation
  
  careerGoal: "To engineer reliable software solutions, continuously sharpen core computer science fundamentals, and contribute to cutting-edge projects in software engineering, artificial intelligence, and data science.",
  
  // Contact & Social Links (Update these with your real handles)
  email: "gauransh.developer@example.com", // Replace with your actual email
  github: "https://github.com/gauransh-dev", // Replace with your GitHub profile
  linkedin: "https://linkedin.com/in/gauransh-dev", // Replace with your LinkedIn profile
  twitter: "https://twitter.com/gauransh_dev", // Optional
  resumeUrl: "#", // Add link to your PDF resume when ready
  
  // Status badge shown in hero
  status: {
    availableFor: "Open to Collaborations & Internships",
    isAvailable: true,
  }
};

export const aboutData = {
  intro: [
    "I am currently in my second year pursuing a Bachelor of Computer Applications (BCA) at Swami Rama Himalayan University (SRHU) in the scenic foothills of Uttarakhand, India.",
    "My journey in tech began with a deep curiosity for how computer logic turns abstract concepts into real-world applications. Starting with foundational C programming and data structures, I've developed a rigorous problem-solving mindset that values efficiency, clean architecture, and practical execution.",
    "Beyond academic coursework, I actively explore Artificial Intelligence, Machine Learning, and Data Science. I love brainstorming innovative hackathon ideas, experimenting with modern web tools, and collaborating with fellow students to build software that creates tangible value."
  ],
  pillars: [
    {
      title: "Algorithmic Foundation",
      description: "Rooted in C programming and fundamental Data Structures, focusing on memory awareness, step-by-step logic, and clean code.",
      icon: "Code2"
    },
    {
      title: "Exploring AI & Data Science",
      description: "Fascinated by machine learning algorithms, data analysis, and using statistical insights to solve real-world problems.",
      icon: "Cpu"
    },
    {
      title: "Product-Oriented Mindset",
      description: "Passionate about conceptualizing real apps—like gamified fitness platforms and campus tools—with user-first thinking.",
      icon: "Rocket"
    },
    {
      title: "Curious & Continuous Learner",
      description: "Dedicated to continuous daily practice, exploring developer documentation, and collaborating on hackathon initiatives.",
      icon: "Sparkles"
    }
  ],
  quickStats: [
    { label: "University", value: "SRHU, Uttarakhand" },
    { label: "Degree Program", value: "BCA (2nd Year)" },
    { label: "Core Foundation", value: "C & Data Structures" },
    { label: "Primary Interests", value: "AI/ML, Data Science, Web" }
  ]
};

export const skillsData = {
  categories: [
    {
      id: "programming",
      name: "Programming",
      tagline: "Core languages and computational fundamentals",
      skills: [
        {
          name: "C Language",
          description: "Pointers, dynamic memory management, structured programming, and modular logic.",
          levelNote: "Primary academic & logic foundation",
          icon: "Terminal"
        },
        {
          name: "Data Structures (C)",
          description: "Arrays, Linked Lists, Stacks, Queues, Sorting (Bubble, Selection, Insertion) & Searching algorithms.",
          levelNote: "Active practice & university coursework",
          icon: "Binary"
        }
      ]
    },
    {
      id: "web-dev",
      name: "Web Development",
      tagline: "Building responsive and accessible interfaces",
      skills: [
        {
          name: "HTML5",
          description: "Semantic web markup, accessible DOM structure, and clean modern web standards.",
          levelNote: "Clean structure & accessibility",
          icon: "Layout"
        },
        {
          name: "CSS3",
          description: "Responsive design, Flexbox, CSS Grid, custom properties, and modern animations.",
          levelNote: "Responsive UI & styling",
          icon: "Palette"
        },
        {
          name: "JavaScript (ES6+)",
          description: "DOM manipulation, ES6 syntax (arrow functions, promises, array methods), and interactive events.",
          levelNote: "Interactive client-side logic",
          icon: "FileCode"
        }
      ]
    },
    {
      id: "cs-core",
      name: "Computer Science",
      tagline: "Theoretical and practical pillars of computing",
      skills: [
        {
          name: "Data Structures",
          description: "Linear & non-linear structures, algorithmic efficiency, and space-time trade-offs.",
          levelNote: "Core analytical pillar",
          icon: "Layers"
        },
        {
          name: "Problem-Solving",
          description: "Deconstructing complex problems into deterministic steps and testable edge cases.",
          levelNote: "Algorithmic thinking",
          icon: "Brain"
        },
        {
          name: "Database Fundamentals",
          description: "Relational database models, primary & foreign keys, SQL querying basics, and normalization.",
          levelNote: "Relational concepts & SQL",
          icon: "Database"
        }
      ]
    },
    {
      id: "interests",
      name: "Areas of Interest",
      tagline: "Technologies and domains currently exploring",
      skills: [
        {
          name: "Artificial Intelligence & ML",
          description: "Supervised & unsupervised learning concepts, neural network architectures, and modern AI tooling.",
          levelNote: "Actively studying & researching",
          icon: "Bot"
        },
        {
          name: "Data Science",
          description: "Data exploration, statistical distributions, pattern recognition, and data-driven reasoning.",
          levelNote: "Learning analytical workflows",
          icon: "LineChart"
        },
        {
          name: "Mobile App Development",
          description: "Mobile UX/UI principles, cross-platform app architecture, and fitness tracking workflows.",
          levelNote: "Concept research & design",
          icon: "Smartphone"
        }
      ]
    }
  ]
};

export const featuredProjects = [
  {
    id: "fitness-sports-app",
    title: "Fitness & Sports Competition App",
    badge: "Featured Concept & Architecture",
    status: "Concept / In Active Design",
    statusType: "concept", // 'concept' | 'in-progress' | 'completed'
    shortDescription: "A social fitness and sports competition platform inspired by activity-tracking ecosystems, enabling users to join running challenges, compete on leaderboards, and motivate friends.",
    problemSolved: "Traditional fitness trackers often feel solitary. Runners and athletes frequently struggle to stay motivated without accountability, peer interaction, and healthy competitive dynamics.",
    solution: "Designed a gamified social platform where users can log running activities, initiate head-to-head or group challenges, track comparative metrics, and celebrate milestones on dynamic leaderboards.",
    keyFeatures: [
      "Running challenge creator with custom distance, time, and pace benchmarks",
      "Dynamic real-time leaderboard with tiered ranking (Global, Campus, Friends)",
      "Peer invite system & accountability squads with activity feeds",
      "Performance comparison tool analyzing pace splits and distance progression",
      "Milestone badges & digital trophies for athletic consistency"
    ],
    techStack: [
      "React / React Native Concept",
      "JavaScript",
      "Tailwind CSS",
      "RESTful API Architecture",
      "Relational Database (SQL)",
      "Geolocation Tracking API (Concept)"
    ],
    githubUrl: "https://github.com/gauransh-dev", // Editable link
    liveUrl: null, // Clearly marked: Concept phase
    hasArchitectureModal: true,
    highlights: [
      "Social-first sports accountability",
      "Gamified leaderboards",
      "Designed for runners & athletes"
    ]
  },
  {
    id: "campus-task-tracker",
    title: "BCA Academic & Task Planner",
    badge: "Student Utility Tool",
    status: "In Progress / Prototype",
    statusType: "in-progress",
    shortDescription: "A minimalist dashboard designed for university computer science students to organize daily coding practice, lecture notes, and lab assignment deadlines.",
    problemSolved: "BCA students balance programming labs, theoretical subjects, and personal projects. Generic planners lack focus on coding logs and syllabus tracking.",
    solution: "A streamlined web dashboard tracking daily C/DSA problem counts, upcoming university submissions, and quick links to lecture resources.",
    keyFeatures: [
      "Daily DSA practice problem counter with topic tags",
      "SRHU semester coursework syllabus checklist",
      "Clean dark mode interface optimized for study sessions",
      "Local state persistence for privacy and instant responsiveness"
    ],
    techStack: ["JavaScript", "HTML5", "CSS3 / Tailwind", "Local Storage"],
    githubUrl: "https://github.com/gauransh-dev",
    liveUrl: null,
    hasArchitectureModal: false,
    highlights: [
      "Built for BCA coursework",
      "Zero clutter study interface"
    ]
  },
  {
    id: "algo-visualizer-concept",
    title: "C Algorithm Visualizer Concept",
    badge: "Educational Project Concept",
    status: "Exploring / Planned",
    statusType: "planned",
    shortDescription: "An interactive educational visualizer conceptualized to demystify pointer mechanics and sorting algorithms (Bubble, Selection, Insertion) in C.",
    problemSolved: "Beginner programming students often struggle to visualize how array elements swap and how pointers traverse memory blocks during sorting routines.",
    solution: "Step-by-step visual playback demonstrating memory addresses, index pointers, and value swaps with synchronized code highlights.",
    keyFeatures: [
      "Visual step-by-step sorting playback with pause & speed controls",
      "Side-by-side C syntax highlighting matching array state",
      "Interactive memory pointer tracker"
    ],
    techStack: ["C Logic", "JavaScript", "HTML5 Canvas / DOM", "CSS3"],
    githubUrl: "https://github.com/gauransh-dev",
    liveUrl: null,
    hasArchitectureModal: false,
    highlights: [
      "Visual memory pointer tracking",
      "Designed for CS peer learning"
    ]
  }
];

export const educationData = {
  degree: "Bachelor of Computer Applications (BCA)",
  university: "Swami Rama Himalayan University (SRHU)",
  location: "Jolly Grant, Dehradun, Uttarakhand, India",
  duration: "2024 – 2027 (Expected)",
  currentStatus: "Second-Year Undergraduate Student",
  description: "Pursuing rigorous computer science fundamentals with an emphasis on structured programming, computational logic, data structures, and database management systems.",
  coursework: [
    "C Programming & Problem Solving",
    "Data Structures & Algorithms",
    "Database Management Systems (DBMS)",
    "Computer Organization & Architecture",
    "Discrete Mathematics",
    "Web Technology & Internet Basics",
    "Operating Systems Concepts"
  ],
  academicFocus: "Actively applying classroom computer science theory into hands-on code experiments, campus peer projects, and technical exploration."
};

export const currentlyLearningData = [
  {
    topic: "Artificial Intelligence & Machine Learning",
    icon: "Brain",
    accentColor: "from-cyan-500 to-blue-500",
    description: "Studying core machine learning theory, supervised learning principles, cost functions, gradient descent, and exploring foundational Python data tools.",
    milestones: [
      "Understanding regression and classification algorithms",
      "Exploring Python scientific libraries (NumPy, Pandas concept)",
      "Neural network basics and AI application patterns"
    ]
  },
  {
    topic: "Data Science & Data Analysis",
    icon: "BarChart3",
    accentColor: "from-blue-500 to-indigo-500",
    description: "Learning how to clean, structure, and extract meaningful patterns from data to support objective decision-making.",
    milestones: [
      "Data wrangling and tabular dataset exploration",
      "Statistical foundations (variance, standard deviation, correlation)",
      "Data visualization techniques and charting"
    ]
  },
  {
    topic: "Software Development & Architecture",
    icon: "Code",
    accentColor: "from-indigo-500 to-purple-500",
    description: "Building modern, maintainable web applications using modular components, Git version control, and clean code conventions.",
    milestones: [
      "Modern JavaScript ES6+ patterns and asynchronous flows",
      "Component-driven development with React & Tailwind CSS",
      "Git workflow, GitHub collaboration, and clean repository hygiene"
    ]
  },
  {
    topic: "Data Structures & Algorithmic Logic",
    icon: "Binary",
    accentColor: "from-purple-500 to-pink-500",
    description: "Deepening practical implementation of linked lists, stacks, queues, recursion, and time complexity analysis in C.",
    milestones: [
      "Pointer manipulation and memory allocation in C",
      "Recursive problem breakdown and backtracking concepts",
      "Big-O time and space complexity evaluations"
    ]
  }
];

export const achievementsData = {
  note: "Authentic record of verified academic participation, campus workshops, and learning milestones. As new hackathons and certifications are completed, they will appear here.",
  items: [
    {
      title: "Active BCA 2nd-Year Scholar",
      organization: "Swami Rama Himalayan University (SRHU)",
      year: "2024 – Present",
      type: "Academic",
      description: "Consistent academic focus in computer science subjects, participating actively in campus coding exercises and lab sessions."
    },
    {
      title: "University Technical Seminars & Workshops",
      organization: "SRHU Department of Computer Applications",
      year: "2024 – 2025",
      type: "Workshop",
      description: "Attended technical seminars and hands-on workshops introducing emerging trends in software, computing infrastructure, and programming practices."
    },
    {
      title: "C Programming & Problem Solving Foundation",
      organization: "Self-Directed & Academic Labs",
      year: "2024 – 2025",
      type: "Technical Milestone",
      description: "Completed comprehensive hands-on implementation of foundational data structures and algorithm routines in C."
    },
    {
      title: "Upcoming: Hackathon & Project Showcases",
      organization: "Regional & Collegiate Competitions",
      year: "2026",
      type: "In Preparation",
      description: "Actively drafting project architectures and teaming up with peers to participate in upcoming collegiate hackathons."
    }
  ]
};

